package com.WeightTrackerApp;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class LoginFragment extends Fragment {

    private EditText mUsernameEditText;
    private EditText mPasswordEditText;
    private Button mLoginButton;
    private Button mCreateAccountButton;
    private OnLoginSuccessListener mListener;

    /*
    The OnLoginSuccessListener interface is used to notify the hosting activity that the login was successful.
     */
    public interface OnLoginSuccessListener {
        void onLoginSuccess();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.login_fragment, container, false);

        // Initialize views
        mUsernameEditText = view.findViewById(R.id.username_edittext);
        mPasswordEditText = view.findViewById(R.id.password_edittext);
        mLoginButton = view.findViewById(R.id.login_button);
        mCreateAccountButton = view.findViewById(R.id.create_account_button);

        // Set click listeners for buttons
        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                attemptLogin();
            }
        });

        mCreateAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount();
            }
        });

        return view;
    }
    /*
    The attemptLogin() method is called when the login button is clicked.
    It checks if both username and password fields are filled out, and then checks if the entered username and password are valid.
    If they are, it notifies the OnLoginSuccessListener that the login was successful.
     */
    private void attemptLogin() {
        String username = mUsernameEditText.getText().toString().trim();
        String password = mPasswordEditText.getText().toString().trim();

        // Check if fields are empty
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(getActivity(), "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // TODO: Check if username and password are valid

        // Notify listener that login was successful
        mListener.onLoginSuccess();
    }
    /*
    The createAccount() method is called when the create account button is clicked.
    This method will open the create account screen when implemented.
     */
    private void createAccount() {
        // TODO: Open create account screen
    }
    /*
    The onAttach() method is overridden to ensure that the hosting activity implements the OnLoginSuccessListener interface.
     */
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnLoginSuccessListener) {
            mListener = (OnLoginSuccessListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnLoginSuccessListener");
        }
    }
    /*
    The onDetach() method is overridden to set the listener to null to prevent memory leaks.
     */
    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
}
