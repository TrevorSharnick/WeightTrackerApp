
package com.WeightTrackerApp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "Users.db";
    private static final int VERSION = 1;

    private static UserDatabase instance;

    private UserDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static UserDatabase getInstance(Context context){
        if (instance == null){
            instance = new UserDatabase(context);
        }

        return instance;
    }

    private static final class UserTable {

        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + "( " +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + ", " +
                UserTable.COL_PASSWORD + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }
    // TODO: continue this database code
    public List<>
}
