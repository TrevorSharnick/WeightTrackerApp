package com.WeightTrackerApp;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

/* This activity will be used for hosting the support fragment (ADDING LoginFragment to LoginActivity.java).
- To manage fragments, the LoginActivity class needs to use the FragmentManager.
- FragmentManager handles two things:
1) A list of fragments
2) A back stack of fragment transactions
 */
public class LoginActivity extends AppCompatActivity implements LoginFragment.OnLoginSuccessListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        // Add the LoginFragment to the activity
        FragmentManager fm = getSupportFragmentManager();
        // Now that you have the FragmentManager, the following code will give it a fragment to manage (the login_fragment_container in login_activity.xml)
        // *** When you need to retrieve the LoginFragment from FragmentManager, you ask for it by container view ID: ***
        Fragment fragment = fm.findFragmentById(R.id.login_fragment_container);

        if (fragment == null) {
            fragment = new LoginFragment();

            fm.beginTransaction()
                    .add(R.id.login_fragment_container, new LoginFragment())
                    .commit();
        }
    }

    @Override
    public void onLoginSuccess() {
        // Handle successful login
        Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
        // TODO: Navigate to the main activity
    }
}