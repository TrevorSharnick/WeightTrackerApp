package com.WeightTrackerApp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class WeightsDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "DailyWeights.db";
    private static final int VERSION = 1;


    private static WeightsDatabase instance;

    private WeightsDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static WeightsDatabase getInstance(Context context){
        if (instance == null){
            instance = new WeightsDatabase(context);
        }

        return instance;
    }

    private static final class DailyWeightsTable{
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_DESCRIPTION = "description";
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + DailyWeightsTable.TABLE + "( " +
                DailyWeightsTable.COL_ID + " integer primary key autoincrement, " +
                DailyWeightsTable.COL_NAME + ", " +
                DailyWeightsTable.COL_DESCRIPTION + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + DailyWeightsTable.TABLE);
        onCreate(db);
    }

    public List<Weight> getDailyWeights(){
        List<Weight> dailyWeights = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT * FROM " + DailyWeightsTable.TABLE;

        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()){
            do {
                long id = cursor.getInt(0);
                String name = cursor.getString(1);
                String description = cursor.getString(2);
                Weight dailyWeight= new Weight(id, name, description);
                dailyWeights.add(dailyWeight);
            } while (cursor.moveToNext());
        }

        return dailyWeights;
    }
    // TODO: Make changes to this to accomodate the weight system rather than bands
    public Weight getWeight(long weightId){
        Weight band = null;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + DailyWeightsTable.TABLE + " WHERE " + DailyWeightsTable.COL_ID + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{Long.toString(weightId)});

        if (cursor.moveToFirst()){

            String name = cursor.getString(1);
            String description = cursor.getString(2);
            band = new Weight(weightId, name, description);
        }

        return band;
    }

    public long addBand(Weight band){

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DailyWeightsTable.COL_NAME, band.getName());
        values.put(DailyWeightsTable.COL_DESCRIPTION, band.getDescription());
        long newId = db.insert(DailyWeightsTable.TABLE, null, values);

        return newId;
    }

    public boolean editBand(long id, Weight band){
        boolean isEdited = false;
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(DailyWeightsTable.COL_ID, id);
        values.put(DailyWeightsTable.COL_NAME, band.getName());
        values.put(DailyWeightsTable.COL_DESCRIPTION, band.getDescription());

        int result = db.update(DailyWeightsTable.TABLE, values, DailyWeightsTable.COL_ID + " = " + id, null);

        return result == 1;
    }

    public boolean deleteBand(long id){
        SQLiteDatabase db = getWritableDatabase();

        int result = db.delete(DailyWeightsTable.TABLE, DailyWeightsTable.COL_ID + " = " + id, null);
        return result == 1;
    }
}


