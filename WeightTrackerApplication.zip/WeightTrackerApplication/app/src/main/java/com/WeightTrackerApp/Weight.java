package com.WeightTrackerApp;

import java.util.Objects;

public class Weight {

    private long id;
    private String name;
    private String description;

    /**
     * Get the id
     *
     * @return - the id
     */
    public long getId() {
        return id;
    }
    // TODO: fix issues with the get methods, adjust the Weight class attributes to fit
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Weight(long id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public Weight(String name, String description) {
        this(-1, name, description);
    }

    public Weight(long id, Weight band) {
        this(id, weight.name, band.description);
    }

    public Weight(Weight b) {
        this(b.id, b.name, b.description);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Weight band = (Weight) o;
        return id == band.id && Objects.equals(name, band.name) && Objects.equals(description, band.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, description);
    }
}